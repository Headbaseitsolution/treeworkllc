import styles from "../styles/Home.module.css";
export default function BreadcrumbBlogs() {
  return (
    <div className={`${styles.container_fluid} ${styles.for_bg}`}>
      <div className="bz-banner2">
        <div className="y-middle1">
          <h1 className="header">Blog</h1>
        </div>
      </div>
    </div>
  );
}
